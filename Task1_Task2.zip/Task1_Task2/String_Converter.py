#import necessary libraries 
import tkinter as tk
import logging
import datetime
import argparse

# Set up logging
logging.basicConfig(filename='string_converter.log', level=logging.DEBUG, format='%(asctime)s %(levelname)s: %(message)s')
def parse_args():
    parser = argparse.ArgumentParser(description='Convert a string of at least 3 words to a new string where the first letter of each word and every alternate letter is capitalized')
    parser.add_argument('-i','--input', help='The input string to convert')
    return parser.parse_args()

class StringConverter:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("String Converter")

        # Set up the dimensions and position of the window
        self.root_width = self.root.winfo_screenwidth() // 2
        self.root_height = self.root.winfo_screenheight() // 2
        self.x_pos = (self.root.winfo_screenwidth() // 2) - (self.root_width // 2)
        self.y_pos = (self.root.winfo_screenheight() // 2) - (self.root_height // 2)
        self.root.geometry('{}x{}+{}+{}'.format(self.root_width, self.root_height, self.x_pos, self.y_pos))
        self.root.config(bg="#F0F0F0")

        # Set up the title label
        self.title_label = tk.Label(self.root, text="String Converter", font=("Arial", 24, "bold"), bg="#F0F0F0")
        self.title_label.pack(pady=20)

        # Set up the input frame and input box
        self.input_frame = tk.Frame(self.root, bg="#F0F0F0")
        self.input_frame.pack(pady=20)

        self.input_label = tk.Label(self.input_frame, text="Enter a string of at least 3 words:", font=("Arial", 16), bg="#F0F0F0")
        self.input_label.pack(side="left", padx=10)

        self.input_box = tk.Entry(self.input_frame, font=("Arial", 16), width=30)
        self.input_box.pack(side="left")

        # Set up the convert and help buttons
        self.convert_button = tk.Button(self.root, text="Convert", font=("Arial", 16, "bold"), bg="#4CAF50", fg="#000000", command=self.convert_string)
        self.convert_button.pack(pady=20)

        self.help_button = tk.Button(self.root, text=" ? ", font=("Arial", 16), bg="#F0F0F0", fg="#000000", command=self.show_help)
        self.help_button.pack(side="right", anchor="se", padx=30, pady=30)
        self.help_button.config(highlightbackground="#2196F3", activebackground="#2196F3")

        # Set up the output label
        self.output_frame = tk.Frame(self.root, bg="#F0F0F0")
        self.output_frame.pack()

        self.output_label = tk.Label(self.output_frame, text="", font=("Arial", 16), bg="#F0F0F0")
        self.output_label.pack(pady=20)

    def run(self):
        self.root.mainloop()

    def convert_string(self):
        """Convert the user's input string into a new string where the first letter of each word and every alternate letter is capitalized."""
        # Get the user's input string from the input_box
        user_input = self.input_box.get()

        # Split the input string into words
        words = user_input.split()
        
        # Error handling for invalid input
        if len(user_input) == 0:
            self.output_label.config(text="Input is empty. Please enter a string of at least 3 words.")
            logging.warning("Empty input.")
            print("Empty input.")
            return

        # Check if the input string has at least 3 words
        elif len(words) < 3:
            error_message="Invalid input. Please enter a string of at least 3 words."
            self.output_label.config(text=error_message)

            # Log the error message to a file
            with open("string_converter.log", "a") as f:
                f.write(f"[ERROR] {datetime.datetime.now()} - {error_message}\n")
                print(f"[ERROR] {datetime.datetime.now()} - {error_message}\n")
            return
        output = ""
        is_caps=False
        for char in (user_input):
            if char==' ':
                output += char
                continue
            elif not is_caps:
                output+=char.upper()
                is_caps=True
            else:
                output+=char.lower()
                is_caps=False
        output += " "
        with open("string_converter.log", "a") as f:
            f.write(f"[SUCCESS] {datetime.datetime.now()} - Converted {' '.join(words)} to {output}\n")
            print(f"[SUCCESS] {datetime.datetime.now()} - Converted {' '.join(words)} to {output}\n")


        self.output_label.config(text=output)
        print(f'Transformed Output: {output}')

    def show_help(self):
        # Define the help text
        help_text = "This script converts a string of at least 3 words into a new string where the first letter of each word and every alternate letter is capitalized, respectively."
        # Create a new window for the help information
        help_window = tk.Toplevel(self.root)
        # Set the title of the help window
        help_window.title("Help")
        # Create a label to display the help text in the window
        help_label = tk.Label(help_window, text=help_text, font=("Arial", 12), padx=10, pady=10)
        help_label.pack()
        # Create an "OK" button to close the window when clicked
        help_ok_button = tk.Button(help_window, text="OK", font=("Arial", 12, "bold"),bg="#4CAF50", fg="#000000", command=help_window.destroy)
        help_ok_button.pack(pady=10)
        # Display the help window
        help_window.mainloop()

if __name__ == '__main__':
    args= parse_args()
    
    # Instantiate StringConverter class
    app = StringConverter()
    if args.input is not None:
        # Set the input_box value to the string input
        app.input_box.insert(0, args.input)

        # Call the convert_string method
        app.convert_string()
    else:
        app.run()