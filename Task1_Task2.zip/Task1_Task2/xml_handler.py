import logging
import tkinter as tk
import tkinter.ttk as ttk
from tkinter import filedialog
import xml.etree.ElementTree as ET
import pandas as pd
import sys, argparse

# Create a logger object
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

# Create a file handler and set the logging level to INFO
file_handler = logging.FileHandler('xml_to_excel.log')
file_handler.setLevel(logging.INFO)

# Create a stream handler and set the logging level to DEBUG
stream_handler = logging.StreamHandler(sys.stdout)
stream_handler.setLevel(logging.DEBUG)

# Create a formatter and add it to the file handler
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
file_handler.setFormatter(formatter)
stream_handler.setFormatter(formatter)


# Add the file handler to the logger
logger.addHandler(file_handler)
logger.addHandler(stream_handler)

def parse_args():
    parser = argparse.ArgumentParser(description='Convert a string of at least 3 words to a new string where the first letter of each word and every alternate letter is capitalized')
    parser.add_argument('-xml','--xml_path', help='The path of arxml file')
    parser.add_argument('-xlsx','--excel_path', help='The path of the excel file where it should be saved.')
    return parser.parse_args()

class xml_handler_gui:
    def __init__(self):
        # Create the GUI window
        self.root = tk.Tk()
        self.root.title('XML to Excel Converter')
        #Create the XML file path label and entry box
        self.xml_path_label = tk.Label(self.root, text='XML File Path:')
        self.xml_path_label.grid(row=0, column=0, padx=5, pady=5)

        self.xml_path_entry = tk.Entry(self.root, width=50)
        self.xml_path_entry.grid(row=0, column=1, padx=5, pady=5)

        self.xml_browse_button = tk.Button(self.root, text='Browse', command=self.browse_xml_file)
        self.xml_browse_button.grid(row=0, column=2, padx=5, pady=5)

        #Create the Excel file path label and entry box
        self.excel_path_label = tk.Label(self.root, text='Excel File Path:')
        self.excel_path_label.grid(row=1, column=0, padx=5, pady=5)

        self.excel_path_entry = tk.Entry(self.root, width=50)
        self.excel_path_entry.grid(row=1, column=1, padx=5, pady=5)

        self.excel_browse_button = tk.Button(self.root, text='Browse', command=self.browse_excel_file)
        self.excel_browse_button.grid(row=1, column=2, padx=5, pady=5)
        self.progress_bar = ttk.Progressbar(self.root, orient="horizontal", length=300, mode="determinate")
        self.help_button = tk.Button(self.root, text="  ?  ",command=self.show_help)
        self.help_button.grid(row=3, column=5, padx=15, pady=15)
        #self.help_button.config(highlightbackground="#2196F3", activebackground="#2196F3")

        #Create the Convert button
        self.convert_button = tk.Button(self.root, text='Convert', command=self.convert_xml_to_excel)
        self.convert_button.grid(row=2, column=1, padx=5, pady=5)
        #Create the success/error message label
        self.success_label = tk.Label(self.root, text='', font=('Arial', 12))
        self.success_label.grid(row=3, column=1, padx=5, pady=5)

    def run(self):
        self.root.mainloop()

    # Define function to browse and select XML file
    def browse_xml_file(self):
        try:
            file_path = filedialog.askopenfilename(filetypes=[('XML files', '*.xml')])
            self.xml_path_entry.delete(0, tk.END)
            self.xml_path_entry.insert(0, file_path)
        except Exception as e:
            logger.error(f'Error browsing XML file: {e}')

    # Define function to browse and select Excel file
    def browse_excel_file(self):
        try:
            file_path = filedialog.asksaveasfilename(filetypes=[('Excel files', '*.xlsx')])
            self.excel_path_entry.delete(0, tk.END)
            self.excel_path_entry.insert(0, file_path)
        except Exception as e:
            logger.error(f'Error browsing Excel file: {e}')

    # function which would show progress of the process
    def update_progress(self,progress_value):
        self.progress_bar['value'] = progress_value
        self.root.update_idletasks()

    def show_help(self):
        # Define the help text
        help_text = "This script extracts data of SHORT-NAME, DEFINATION-REF of the containers and sub-containers of the arxml."
        # Create a new window for the help information
        help_window = tk.Toplevel(self.root)
        # Set the title of the help window
        help_window.title("Help")
        # Create a label to display the help text in the window
        help_label = tk.Label(help_window, text=help_text, font=("Arial", 12), padx=10, pady=10)
        help_label.pack()
        # Create an "OK" button to close the window when clicked
        help_ok_button = tk.Button(help_window, text="OK", font=("Arial", 12, "bold"),bg="#4CAF50", fg="#000000", command=help_window.destroy)
        help_ok_button.pack(pady=10)
        # Display the help window
        help_window.mainloop()

    # Define function to convert XML to Excel
    def convert_xml_to_excel(self):
        # Get the XML and Excel file paths
        self.progress_bar.grid(row=4, column=1, padx=5, pady=5)
        self.update_progress(10)
        xml_path = self.xml_path_entry.get()
        excel_path = self.excel_path_entry.get()
        try:
            # parse the XML data
            try:
                tree = ET.parse(xml_path)
            except Exception as e:
                print(e)
            # get the root element of the XML tree
            root = tree.getroot()

            # get the xmlns attribute of the root element
            xmlns = root.tag.split('}')[0] + '}'

            # create a list to hold our data
            data = []
            container_no=1
            # iterate through each CONTAINER element
            self.update_progress(20)
            for container in root.iter(xmlns + 'CONTAINERS'):
                for element in container.iter():
                    if element.find(xmlns + 'SHORT-NAME') is not None:
                        short_name = element.find(xmlns + 'SHORT-NAME').text
                        def_ref = element.find(xmlns + 'DEFINITION-REF').text
                        data.append({
                            'Containers': container_no,
                            'Short Name': short_name,
                            'Definition Ref': def_ref,
                            'Sub-Containers': '',
                            'Sub-Short Name': '',
                            'Sub-Definition Ref': ''
                        })
                        break
                self.update_progress(45)
                # iterate through each SUB-CONTAINER element within the current container
                sub_container_no=.1
                for sub_container in container.iter(xmlns + 'SUB-CONTAINERS'):
                    for element in sub_container.iter():
                        if element.find(xmlns + 'SHORT-NAME') is not None:
                            short_name = element.find(xmlns + 'SHORT-NAME').text
                            def_ref = element.find(xmlns + 'DEFINITION-REF').text
                            data.append({
                                'Containers': '',
                                'Short Name': '',
                                'Definition Ref': '',
                                'Sub-Containers': float(container_no + sub_container_no),
                                'Sub-Short Name': short_name,
                                'Sub-Definition Ref':def_ref
                            })
                            break
                    sub_container_no+=.1
                container_no+=1
                self.update_progress(60)
            # convert list to pandas
            df = pd.DataFrame(data)
            self.update_progress(80)
            # write DataFrame to Excel file
            try:
                df.to_excel(excel_path, index=False)
            except Exception as e:
                print(e)
            
            self.update_progress(100)
            # show success message
            self.success_label.config(text='Conversion successful !', fg='green')
            logger.info('Conversion successful !')
            self.progress_bar.grid_forget()
        except Exception as e:
            # show error message
            self.success_label.config(text='Error: ' + str(e), fg='red')


if __name__ == '__main__':
    app = xml_handler_gui()
    
    args=parse_args()
    #CLI MODE
    if args.xml_path is not None and args.excel_path is not None:
        print('Starting executable in CLI mode')
        app.xml_path_entry.insert(0,args.xml_path)
        app.excel_path_entry.insert(0,args.excel_path)
        app.convert_xml_to_excel()
    #GUI mode
    else:
        print('Starting app in GUI mode as at least one of the required commands for cli are not passed.')
        app.run()